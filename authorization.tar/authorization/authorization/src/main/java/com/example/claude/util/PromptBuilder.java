package com.example.claude.util;

import org.springframework.stereotype.Component;

@Component
public class PromptBuilder {

    /*
     * type = "Controller" → for UserController.java
     * */
    public String buildTestPrompt(String code, String type){



        return
                """
        You are a senior Java developer.

        Generate JUnit 5 test cases using Mockito for the following %s class.

        Requirements:
        - Cover all methods
        - Positive scenarios
                - Negative scenarios
                - Exception handling
                - Mock dependencies
                - Achieve high code coverage
                - Use best practices
        - Naming convention of method should be test_scenario_result
                - method name starts with test
                - scenario = negative/positive with min words
                - result =  what is the expected result of that scenarios.
                    - if negative testcase, mention as  returnNull etc
                    - if positive testcase, mention as returnResponse
                 

        Return only complete Java test class.

        Code:
            %s
        """.formatted(type, code);


    }
}
