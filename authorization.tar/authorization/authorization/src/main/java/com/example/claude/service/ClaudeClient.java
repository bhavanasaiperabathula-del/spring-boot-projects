package com.example.claude.service;

import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;
import java.util.Map;

@Service
public class ClaudeClient {

    private final WebClient webClient;

    public ClaudeClient(WebClient webClient) {
        this.webClient = webClient;
    }

    public String generateResponse(String prompt) {

        Map<String, Object> request = Map.of(
                "model", "claude-3-sonnet-20240229",
                "max_tokens", 2000,
                "messages", List.of(
                        Map.of("role", "user", "content", prompt)
                )
        );

        return webClient.post()
                .uri("/v1/messages")
                .bodyValue(request)
                .retrieve()
                .bodyToMono(String.class)
                .block();
    }
}

