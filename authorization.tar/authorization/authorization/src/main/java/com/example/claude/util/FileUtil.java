package com.example.claude.util;

import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Component
public class FileUtil {
    public String readFile(Path path) throws IOException{
        return Files.readString(path);
    }

    public void writeTestFile(String type, String className, String content) throws IOException{
        Path outputPath = Paths.get("src/test/java/authorization/" + type + "/"+ className + "Test.java");
        Files.writeString(outputPath, content);

        System.out.println("Test file created: " + outputPath);
    }
}
