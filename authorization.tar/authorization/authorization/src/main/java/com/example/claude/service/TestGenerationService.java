package com.example.claude.service;

import com.example.claude.util.FileUtil;
import com.example.claude.util.PromptBuilder;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Path;

@Service
public class TestGenerationService {

    private final ClaudeClient claudeClient;
    private final PromptBuilder promptBuilder;
    private final FileUtil fileUtil;

    public TestGenerationService(ClaudeClient claudeClient, PromptBuilder promptBuilder, FileUtil fileUtil) {
        this.claudeClient = claudeClient;
        this.promptBuilder = promptBuilder;
        this.fileUtil = fileUtil;
    }

    public String generateForSingleFile(Path filePath, String type) throws IOException{
        String code = fileUtil.readFile(filePath);
        String prompt = promptBuilder.buildTestPrompt(code, type);
        String response = claudeClient.generateResponse(prompt);

        String className = filePath.getFileName().toString().replace(".java", "");

        fileUtil.writeTestFile(className, type, response);

        return response;
    }

}
