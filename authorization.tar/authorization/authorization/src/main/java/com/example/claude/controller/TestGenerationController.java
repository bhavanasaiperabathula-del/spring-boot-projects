package com.example.claude.controller;


import com.example.claude.service.TestGenerationService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.nio.file.Paths;

@RestController
@RequestMapping("/api/testgen")
public class TestGenerationController {

    private final TestGenerationService service;

    public TestGenerationController(TestGenerationService service) {
        this.service = service;
    }


    @PostMapping("/generate")
    public String generate(@RequestParam String path,
                           @RequestParam String type) throws IOException {

        return service.generateForSingleFile(Paths.get(path), type);
    }

}
