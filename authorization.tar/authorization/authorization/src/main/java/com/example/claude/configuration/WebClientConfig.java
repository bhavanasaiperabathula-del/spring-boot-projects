package com.example.claude.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfig {

    @Bean
    public WebClient webClient(@Value("${anthropic.api-key}") String apiKey, @Value("${anthropic.url}") String url){
        return WebClient.builder().baseUrl(url).defaultHeader("x-api-key",apiKey).defaultHeader("anthropic-version", "2023-06-01").build();
    }
}
